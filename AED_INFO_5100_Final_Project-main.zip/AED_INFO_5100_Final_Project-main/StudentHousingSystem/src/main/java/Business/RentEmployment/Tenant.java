/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.RentEmployment;

import Business.Rent.MailList;
import java.util.Date;

/**
 *
 * @author Aishwarya Katkar
 */
public class Tenant {
    
    private int tenantId;
    private String tenantName;
    private int age;
    private String Gender;
    private String Test;
    private String landlord;
    private TenantHistory tenantHistory;
    private String emailAddress;
    private  String address; 
    private String userName;
    private String phoneNumber;
    private Date birthDate;
    private String bloodGrp;
    private MailList maillist;
    private static int tenantCount=1;
   private String location;
    
    public Tenant(String firstName, String email, String phoneNumber, int age, String homeAddress, 
            String userName, Date birthdate,String bloodGrp,String landlord,String gender,String location){
        this.tenantName = firstName;
        this.emailAddress = email;
        this.phoneNumber = phoneNumber;
        this.age = age;
        this.address = homeAddress;
        this.userName = userName;
        this.tenantId = tenantCount;
        this.birthDate = birthdate;
        this.landlord = landlord;
        this.Gender = gender;
        this.bloodGrp = bloodGrp;
        this.location = location;
        this.maillist = new MailList();
        tenantCount++;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public MailList getMaillist() {
        return maillist;
    }

    public void setMaillist(MailList maillist) {
        this.maillist = maillist;
    }

    public String getLandlord() {
        return landlord;
    }

    public void setLandlord(String landlord) {
        this.landlord = landlord;
    }

  

    
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBloodGrp() {
        return bloodGrp;
    }

    public void setBloodGrp(String bloodGrp) {
        this.bloodGrp = bloodGrp;
    }
    
    

    public int getTenantId() {
        return tenantId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId = tenantId;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getTest() {
        return Test;
    }

    public void setTest(String Test) {
        this.Test = Test;
    }

    public TenantHistory getTenantHistory() {
        return tenantHistory;
    }

    public void setTenantHistory(TenantHistory tenantHistory) {
        this.tenantHistory = tenantHistory;
    }


    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
 
    @Override
     public String toString()
     {
         return this.tenantName;
     }
     
     
}
