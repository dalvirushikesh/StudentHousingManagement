/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.RentEmployment;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Aishwarya Katkar
 */
public class TenantList {
    private ArrayList<Tenant> tenantList;

    public TenantList() {
        tenantList = new ArrayList<Tenant>();
    }

    public ArrayList<Tenant> getTenantList() {
        return tenantList;
    }

    public void setTenantList(ArrayList<Tenant> tenantList) {
        this.tenantList = tenantList;
    }
    
      public Tenant addNewTenant(String fullName, String email, String phoneNumber, int age, String homeAddress, 
              String userName, Date birthdate,String bloodGrp,String landlord,String gender,String location)
    {
        Tenant tenant = new Tenant(fullName,email,phoneNumber,age, homeAddress,userName,birthdate,bloodGrp,
                landlord,gender,location);
        tenantList.add(tenant);
        return tenant;
    }
    
    public void removeTenant(Tenant tenant)
    {
        tenantList.remove(tenant);
    }

    
    
    
}
