/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.RentEmployment;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Aishwarya Katkar
 */
public class MaintenanceList {
     private ArrayList<Maintenance> maintenanceList;

    public MaintenanceList() {
        this.maintenanceList = new ArrayList<Maintenance>() ;
    }
    
     public Maintenance addNewMaintenance(String name,  String number, String homeAddress)
    {
        Maintenance maintenance = new Maintenance(name,number,homeAddress);
        maintenanceList.add(maintenance);
        return maintenance ;
    }
   
   

    public ArrayList<Maintenance> getmaintenanceList() {
        return maintenanceList;
    }

    public void setmaintenanceList(ArrayList<Maintenance> maintenanceList) {
        this.maintenanceList = maintenanceList ;
    }
   
}
