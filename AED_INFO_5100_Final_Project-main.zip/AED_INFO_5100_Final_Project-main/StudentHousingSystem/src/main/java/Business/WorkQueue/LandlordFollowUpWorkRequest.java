/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.RentEmployment.Landlord;
import Business.RentEmployment.Tenant;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.ApartmentDetails.ApartmentDetails;
import java.util.Date;

/**
 *
 * @author Aishwarya Katkar
 */
public class LandlordFollowUpWorkRequest extends WorkRequest {
    private ApartmentDetails checkUp;
    private Organization senderOrganization;
    private Organization recieverOrganization;
    private Network senderNetwork;
    private Network recieverNetwork;
    private Tenant tenant  ;
    private Landlord landlord;
    Date requestdate;
    Date acknowledgeDate;
    Date resolveDate;
    String Status ;
    String checkupRequestId ;
      int min = 100;
    int max = 999;

//CHK added at start of random number to identify landlord request
    public LandlordFollowUpWorkRequest() {
        checkUp = new ApartmentDetails();
        int randomNum = (int)(Math.random() * (max - min + 1) + min);
        checkupRequestId= "CHK"+randomNum;
    }

    public String getCheckupRequestId() {
        return checkupRequestId;
    }

    public void setCheckupRequestId(String checkupRequestId) {
        this.checkupRequestId = checkupRequestId;
    }

    
    public Landlord getLandlord() {
        return landlord;
    }

    public void setLandlord(Landlord landlord) {
        this.landlord = landlord;
    }

    
    public ApartmentDetails getCheckUp() {
        return checkUp;
    }

    public void setCheckUp(ApartmentDetails checkUp) {
        this.checkUp = checkUp;
    }

    public Organization getSenderOrganization() {
        return senderOrganization;
    }

    public void setSenderOrganization(Organization senderOrganization) {
        this.senderOrganization = senderOrganization;
    }

    public Organization getRecieverOrganization() {
        return recieverOrganization;
    }

    public void setRecieverOrganization(Organization recieverOrganization) {
        this.recieverOrganization = recieverOrganization;
    }

    public Network getSenderNetwork() {
        return senderNetwork;
    }

    public void setSenderNetwork(Network senderNetwork) {
        this.senderNetwork = senderNetwork;
    }

    public Network getRecieverNetwork() {
        return recieverNetwork;
    }

    public void setRecieverNetwork(Network recieverNetwork) {
        this.recieverNetwork = recieverNetwork;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public Date getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(Date requestdate) {
        this.requestdate = requestdate;
    }

    public Date getAcknowledgeDate() {
        return acknowledgeDate;
    }

    public void setAcknowledgeDate(Date acknowledgeDate) {
        this.acknowledgeDate = acknowledgeDate;
    }

    public Date getResolveDate() {
        return resolveDate;
    }

    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
    
    
}
