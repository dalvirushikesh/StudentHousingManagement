 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Apartment.Apartment;
import Business.RentEmployment.Landlord;
import Business.RentEmployment.Tenant;
import Business.Network.Network;
import Business.Organization.Organization;
import java.util.Date;

/**
 *
 * @author Aishwarya Katkar
 */
public class BillingWorkRequest extends WorkRequest {
    
    //initializing all variables
    private Organization senderOrganization;
    private Organization recieverOrganization;
    private Network senderNetwork;
    private Network recieverNetwork;
    private String billingRequestId;
    private String ApartmentId;
    private String ApartmentName;
    private int noOfUnits;
    private double fundsAvailable;
    private double equipmentPrice;
    private double totalEquipmentCost;
    private Apartment apartment;
    private double fundAllocated;
    private String status;
    Date requestdate;
    Date acknowledgeDate;
    Date resolveDate;
    String Status ;
    int min = 100;
    int max = 999;

//BR at start is for identifying billing work request
    public BillingWorkRequest () {
        int randomNum = (int)(Math.random() * (max - min + 1) + min);
        billingRequestId= "BR"+randomNum;
        
    }

    public Apartment getApartment() {
        return apartment;
    }

    public void setApartment(Apartment apartment) {
        this.apartment = apartment;
    }

    public String getBillingRequestId() {
        return billingRequestId;
    }

    public String getApartmentId() {
        return ApartmentId;
    }

    public void setApartmentId(String ApartmentId) {
        this.ApartmentId = ApartmentId;
    }

    public void setBillingRequestId(String billingRequestId) {
        this.billingRequestId = billingRequestId;
    }

    public double getFundAllocated() {
        return fundAllocated;
    }

    public void setFundAllocated(double fundAllocated) {
        this.fundAllocated = fundAllocated;
    }
    
   
    public Date getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(Date requestdate) {
        this.requestdate = requestdate;
    }

    public Date getAcknowledgeDate() {
        return acknowledgeDate;
    }

    public void setAcknowledgeDate(Date acknowledgeDate) {
        this.acknowledgeDate = acknowledgeDate;
    }

    public Date getResolveDate() {
        return resolveDate;
    }

    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public Organization getSenderOrganization() {
        return senderOrganization;
    }

    public void setSenderOrganization(Organization senderOrganization) {
        this.senderOrganization = senderOrganization;
    }

    public Organization getRecieverOrganization() {
        return recieverOrganization;
    }

    public void setRecieverOrganization(Organization recieverOrganization) {
        this.recieverOrganization = recieverOrganization;
    }

    public Network getSenderNetwork() {
        return senderNetwork;
    }

    public void setSenderNetwork(Network senderNetwork) {
        this.senderNetwork = senderNetwork;
    }

    public Network getRecieverNetwork() {
        return recieverNetwork;
    }

    public void setRecieverNetwork(Network recieverNetwork) {
        this.recieverNetwork = recieverNetwork;
    }

    public String getApartmentName() {
        return ApartmentName;
    }

    public void setApartmentName(String ApartmentName) {
        this.ApartmentName = ApartmentName;
    }

    public int getNoOfUnits() {
        return noOfUnits;
    }

    public void setNoOfUnits(int noOfUnits) {
        this.noOfUnits = noOfUnits;
    }

    public double getFundsAvailable() {
        return fundsAvailable;
    }

    public void setFundsAvailable(double fundsAvailable) {
        this.fundsAvailable = fundsAvailable;
    }

    public double getEquipmentPrice() {
        return equipmentPrice;
    }

    public void setEquipmentPrice(double equipmentPrice) {
        this.equipmentPrice = equipmentPrice;
    }

    public double getTotalEquipmentCost() {
        return totalEquipmentCost;
    }

    public void setTotalEquipmentCost(double totalEquipmentCost) {
        this.totalEquipmentCost = totalEquipmentCost;
    }
    
    
    @Override
    public String toString() {
        return billingRequestId;
    }
    
    
}
