/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Network.Network;
import Business.Organization.Organization;
import java.util.Date;


public class ApartmentWorkRequest {
    private Organization senderOrganization;
    private Organization recieverOrganization;
    private Network senderNetwork;
    private Network recieverNetwork;
    private String ApartmentRequestId;
    private String ApartmentId;
    private String ApartmentName;
    private String Reason;
    private int noOfUnits;
    private double equipmentPrice;
    private String status;
    Date requestdate;
    Date acknowledgeDate;
    Date resolveDate;
    int min = 100;
    int max = 999;
    
    
    
    public ApartmentWorkRequest() {
        int randomNum = (int)(Math.random() * (max - min + 1) + min);
        ApartmentRequestId= "EP"+randomNum;  
    }

    public Organization getSenderOrganization() {
        return senderOrganization;
    }

    public void setSenderOrganization(Organization senderOrganization) {
        this.senderOrganization = senderOrganization;
    }

    public Organization getRecieverOrganization() {
        return recieverOrganization;
    }

    public void setRecieverOrganization(Organization recieverOrganization) {
        this.recieverOrganization = recieverOrganization;
    }

    public Network getSenderNetwork() {
        return senderNetwork;
    }

    public void setSenderNetwork(Network senderNetwork) {
        this.senderNetwork = senderNetwork;
    }

    public Network getRecieverNetwork() {
        return recieverNetwork;
    }

    public void setRecieverNetwork(Network recieverNetwork) {
        this.recieverNetwork = recieverNetwork;
    }

    public String getApartmentRequestId() {
        return ApartmentRequestId;
    }

    public void setApartmentRequestId(String ApartmentRequestId) {
        this.ApartmentRequestId = ApartmentRequestId;
    }

    public String getApartmentId() {
        return ApartmentId;
    }

    public void setApartmentId(String ApartmentId) {
        this.ApartmentId = ApartmentId;
    }

    public String getApartmentName() {
        return ApartmentName;
    }

    public void setApartmentName(String ApartmentName) {
        this.ApartmentName = ApartmentName;
    }

    public String getReason() {
        return Reason;
    }

    public void setReason(String Reason) {
        this.Reason = Reason;
    }

    public int getNoOfUnits() {
        return noOfUnits;
    }

    public void setNoOfUnits(int noOfUnits) {
        this.noOfUnits = noOfUnits;
    }

    public double getEquipmentPrice() {
        return equipmentPrice;
    }

    public void setEquipmentPrice(double equipmentPrice) {
        this.equipmentPrice = equipmentPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(Date requestdate) {
        this.requestdate = requestdate;
    }

    public Date getAcknowledgeDate() {
        return acknowledgeDate;
    }

    public void setAcknowledgeDate(Date acknowledgeDate) {
        this.acknowledgeDate = acknowledgeDate;
    }
    
    @Override
    public String toString() {
        return ApartmentRequestId;
    }
    
    
}
