/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author Aishwarya Katkar
 */
public class LawyerReqWorkRequest extends WorkRequest{
    
    private String lawResult;

    public String getlawResult() {
        return lawResult;
    }

    public void setTestResult(String lawResult) {
        this.lawResult = lawResult;
    }
    
    
}
