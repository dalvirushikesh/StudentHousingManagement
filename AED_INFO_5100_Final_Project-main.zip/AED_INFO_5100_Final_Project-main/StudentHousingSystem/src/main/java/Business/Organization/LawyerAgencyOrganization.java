/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.EmergencyOfficialRole;
import Business.Role.LawyerRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author sharvikabarapatre
 */
public class LawyerAgencyOrganization extends Organization {

    public LawyerAgencyOrganization() {
        super(Organization.Type.LawyerDepartment.getValue());
    }

    public LawyerAgencyOrganization(String name) {
        super(name);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new LawyerRole());
        return roles;
    }

    @Override
    public Type getType() {
        return Organization.Type.LawyerDepartment;
    }
}
