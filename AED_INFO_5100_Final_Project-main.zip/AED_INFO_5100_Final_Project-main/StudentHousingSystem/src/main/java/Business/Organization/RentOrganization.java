/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Rent.Rent;
import Business.Role.LawyerRole;
import Business.Role.RentAdmin;
import Business.Role.RentUser;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author rushikeshdalvi
 */
public class RentOrganization extends Organization{
    private ArrayList<Rent> rentList;
    

    
    public RentOrganization() {
        super(Organization.Type.RentDepartment.getValue());
    }
    public RentOrganization(String name){
        super(name);
          rentList=new ArrayList<Rent>();
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
       // roles.add(new RentAdmin());
        roles.add(new RentUser());
        return roles;
    }
    
    @Override
    public Type getType() {
        return Organization.Type.RentDepartment;
    } 

     public ArrayList<Rent> getRentList() {
        return rentList;
    }

    public void setRentList(ArrayList<Rent> rentList) {
        this.rentList = rentList;
    }
    
     public void addRent(Rent mi)
    {
       
        rentList.add(mi);
        
    }
}
