/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.EmergencyOfficialRole;
import Business.Role.LawyerRole;
import Business.Role.LeasingAgentRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author sharvikabarapatre
 */
public class LeasingAgentOrganization extends Organization {

    public LeasingAgentOrganization() {
        super(Organization.Type.LeasingAgentDepartment.getValue());
    
    }  
    public LeasingAgentOrganization(String name) {
            super(name);
    }
        

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new LeasingAgentRole());
        return roles;
    }
    
     @Override
    public Type getType() {
        return Organization.Type.LeasingAgentDepartment;
    } 

}
