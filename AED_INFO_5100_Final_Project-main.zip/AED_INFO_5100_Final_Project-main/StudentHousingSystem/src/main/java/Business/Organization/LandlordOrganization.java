/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Rent.Mail;
import Business.Role.LandlordRole;
import Business.Role.EmergencyOfficialRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author rushikeshdalvi

 */
public class LandlordOrganization extends Organization {

    private ArrayList<Mail> maillist;
    
    
    public LandlordOrganization() {
        super(Organization.Type.LandlordDepartment.getValue());
        maillist=new ArrayList<Mail>();
    }
     public LandlordOrganization(String name){
        super(name);
    }

     public ArrayList<Mail> getMaillist() {
        return maillist;
    }

    public void setMaillist(ArrayList<Mail> maillist) {
        this.maillist = maillist;
    }
    

    //get supported role
     
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new EmergencyOfficialRole());
        roles.add(new LandlordRole());
        return roles;
    }
    
    @Override
    public Type getType() {
        return Organization.Type.LandlordDepartment;
    } 
    
    public void addMail(Mail mail){
        
         maillist.add(mail);
         
        
    }


}
