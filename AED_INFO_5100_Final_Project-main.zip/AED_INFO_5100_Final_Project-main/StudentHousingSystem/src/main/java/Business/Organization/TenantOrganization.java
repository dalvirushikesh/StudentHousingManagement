/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.SecurityAdminRole;
import Business.Role.TenantRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Aishwarya Katkar
 */
public class TenantOrganization extends Organization{

    public TenantOrganization() {
        super(Organization.Type.TenantDepartment.getValue());
    }
      public TenantOrganization(String name) {
        super(name);
    }
     @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new TenantRole());
        return roles;
    }
    
     @Override
    public Type getType() {
        return Organization.Type.TenantDepartment;
    } 
    
}
