/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Enterprise.SecurityUnit;
import Business.Role.SecurityAdminRole;
import java.util.ArrayList;

/**
 *
 * @author rushikeshdalvi
 */
 //organisation directory created
public class OrganizationDirectory {
    private ArrayList<Organization> organizationList;
    
    public OrganizationDirectory()
    {
        organizationList = new ArrayList<Organization>();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }

    public void setOrganizationList(ArrayList<Organization> organizationList) {
        this.organizationList = organizationList;
    }
    
    public Organization createOrganization(Organization.Type type,String name) {
        Organization organization = null;
        if (type.getValue().equals(Organization.Type.SecurityDepartment.getValue())) {
            organization = new SecurityOrganization(name);
            organizationList.add(organization);
        } 
        else if (type.getValue().equals(Organization.Type.LawyerDepartment.getValue())) {
            organization = new LawyerAgencyOrganization(name);
            organizationList.add(organization);
        } 
        else if (type.getValue().equals(Organization.Type.LandlordDepartment.getValue())){
                    organization=new LandlordOrganization(name);
                    organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.BillingDepartment.getValue())){
                    organization=new BillingOrganization(name);
                    organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.MaintenanceDepartment.getValue())){
                    organization=new MaintenanceOrganization(name);
                    organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.RentDepartment.getValue())){
                  organization=new RentOrganization(name);
                  organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.TenantDepartment.getValue())){
                  organization=new TenantOrganization(name);
                  organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.ApartmentDepartment.getValue())){
                 organization=new ApartmentOrganization(name);
                 organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.PersonDepartment.getValue())){
                 organization=new PersonOrganization(name);
                 organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.LeasingAgentDepartment.getValue())){
                 organization=new LeasingAgentOrganization(name);
                 organizationList.add(organization);
        }
        
        return organization;
    }
    
}
