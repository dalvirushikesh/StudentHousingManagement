/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.EmergencyOfficialRole;
import Business.Role.SecurityAdminRole;
import Business.Role.EmergencyUserRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author sharvikabarapatre
 */
public class SecurityOrganization extends Organization {

    public SecurityOrganization() {
        super(Organization.Type.SecurityDepartment.getValue());
        
    }
    
    public SecurityOrganization(String name){
        super(name);
    }
//adding emergency role 
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
       
        roles.add(new EmergencyUserRole());
        return roles;
    }
    
    @Override
    public Type getType() {
        return Organization.Type.SecurityDepartment;
    } 


}
