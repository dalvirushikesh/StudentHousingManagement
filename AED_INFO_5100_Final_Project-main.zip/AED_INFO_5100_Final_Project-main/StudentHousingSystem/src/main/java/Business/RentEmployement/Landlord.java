/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.RentEmployment;

import java.util.Date;

/**
 *
 * @author sharvikabarapatre
 */
public class Landlord {
    private String tenantName;
    private int age;
    private String Gender;
    private String qualification;
    private Date practicingfrom ;
    private String specilizationName;
    private String LandlordName;
    private Boolean emergencyOfficial;

    public Landlord(String LandlordName,String qualification, String specilizationName,Boolean emergencyOfficial ) {
        this.qualification = qualification;
        this.specilizationName = specilizationName;
        this.LandlordName = LandlordName;
        this.emergencyOfficial = emergencyOfficial;
    }

    public Boolean getEmergencyOfficial() {
        return emergencyOfficial;
    }

    public void setEmergencyOfficial(Boolean emergencyOfficial) {
        this.emergencyOfficial = emergencyOfficial;
    }

           
    public String getLandlordName() {
        return LandlordName;
    }

    public void setLandlordName(String LandlordName) {
        this.LandlordName = LandlordName;
    }

    
    public String getTenantName() {
        return tenantName;
    }

    
    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public Date getPracticingfrom() {
        return practicingfrom;
    }

    public void setPracticingfrom(Date practicingfrom) {
        this.practicingfrom = practicingfrom;
    }

    public String getSpecilizationName() {
        return specilizationName;
    }

    public void setSpecilizationName(String specilizationName) {
        this.specilizationName = specilizationName;
    }
    
    @Override
    public String toString()
    {
        return LandlordName;
    }
    
}
