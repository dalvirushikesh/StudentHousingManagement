/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

//import Business.Customer.CustomerDirectory;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.RentEmployment.TenantList;
import Business.Network.Network;

import Business.Organization.Organization;
//import Business.Restaurant.RestaurantDirectory;
import Business.UserAccount.UserAccount;
//import userinterface.RestaurantAdminRole.AdminWorkAreaJPanel;
import javax.swing.JPanel;
import userinterface.EmergencyUserWorkArea.EmergencyTenantAdminWorkArea;
import userinterface.SecurityUnitAdminArea.SecurityUnitAdminWorkAreaJPanel;
import userinterface.SystemAdminWorkArea.SystemAdminWorkAreaJPanel;

/**
 *
 * @author raunak
 */
public class EmergencyUserRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account,Organization organization,Enterprise enterprise,Network network, EcoSystem business) {
        return new EmergencyTenantAdminWorkArea( userProcessContainer, account, organization, 
         enterprise,  network, business);
        
        //userProcessContainer, business, account,restaurantDirectory
//        return null;
       // return new AdminWorkAreaJPanel(userProcessContainer, business, account,restaurantDirectory);
       
    }
    
     @Override
    public String toString(){
        return (RoleType.EmergencyUserRole.getValue());
    }

    
    
}
