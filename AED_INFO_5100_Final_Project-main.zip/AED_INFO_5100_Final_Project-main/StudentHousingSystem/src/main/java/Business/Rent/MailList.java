/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Rent;

import java.util.ArrayList;

/**
 * 
 * @author rushikeshdalvi
 */
public class MailList {
      private ArrayList<Mail> mailList;
    
    public MailList(){
        mailList=new ArrayList<Mail>();
    }

//get mail
    public ArrayList<Mail> getMailList() {
        return mailList;
    }
//set mail

    public void setMailList(ArrayList<Mail> mailList) {
        this.mailList = mailList;
    }
    

    public Mail addMail(Mail mail){

         mailList.add(mail);
         return mail;
        
    }
}
