/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Rent;

import java.util.Date;

/**
 *
 * @author rushikeshdalvi 
 */
public class Mail {
     private int NoofTimesInaday;
    private int totalDays;
    private String daignosis;

    private String renterName;

    private Date mailDate;
    private String networkName;

    public String getNetworkName() {
        return networkName;
    }

//set network name 
    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }
    
    



    public Date getMailDate() {
        return mailDate;
    }

    public void setMailDate(Date mailDate) {
        this.mailDate = mailDate;
    }
    
    

    public String getRenterName() {
        return renterName;
    }



    public void setRenterName(String renterName) {
        this.renterName = renterName;
    }
    
    

    public String getDaignosis() {
        return daignosis;
    }

    public void setDaignosis(String daignosis) {
        this.daignosis = daignosis;
    }
    

   
    public int getNoofTimesInaday() {
        return NoofTimesInaday;
    }

    public void setNoofTimesInaday(int NoofTimesInaday) {
        this.NoofTimesInaday = NoofTimesInaday;
    }

    public int getTotalDays() {
        return totalDays;
    }


    public void setTotalDays(int totalDays) {
        this.totalDays = totalDays;
    }
    
    
  
    
}
