/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Rent;

import java.util.ArrayList;

/**
 *
 * @author rushikeshdalvi  

 */
public class RentList {
    
     private ArrayList<Rent> rentList;


    public RentList() {
        rentList=new ArrayList<>();
        }

    public ArrayList<Rent> getRentList() {
        return rentList;
    }

//sent arraylist
    public void setRentList(ArrayList<Rent> rentList) {
        this.rentList = rentList;
    }
    
//creating object for add rent
     public Rent addRent()
    {
        Rent mi = new Rent();
        rentList.add(mi);
        return mi;
    }
    

    public void deleteRent(Rent mi){
     rentList.remove(mi);
    }
}
