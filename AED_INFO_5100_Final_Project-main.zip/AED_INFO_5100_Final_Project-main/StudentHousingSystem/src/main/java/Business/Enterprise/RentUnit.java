/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.BillingAdminRole;
import Business.Role.RentAdmin;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author rushikeshdalvi
 */
public class RentUnit extends Enterprise{

    public RentUnit(String name) {
        super(name,EnterpriseType.RentUnit);
    }
    
    @Override    
    public ArrayList<Role> getSupportedRole() {
        roles = new ArrayList<Role>();
        roles.add(new RentAdmin());
       //  roles.add(new PoliceHead());
        return roles;
    }
    
}
