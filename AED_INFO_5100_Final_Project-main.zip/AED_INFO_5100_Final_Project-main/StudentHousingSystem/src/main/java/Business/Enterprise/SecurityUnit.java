/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.MaintenanceRole;
import Business.Role.EmergencyOfficialRole;
import Business.Role.Role;
import java.util.ArrayList;
import Business.Role.SecurityAdminRole;
import Business.Role.LawyerRole;
import Business.Role.TenantRole;
import Business.Role.LeasingAgentRole;

/**
 *
 * @author Aishwarya Katkar
 */
public class SecurityUnit extends Enterprise {
    
    public SecurityUnit(String name) {
        super(name, Enterprise.EnterpriseType.SecurityUnit);
    }

    @Override
    
    public ArrayList<Role> getSupportedRole() {
        roles = new ArrayList<Role>();
        roles.add(new SecurityAdminRole());
        roles.add(new EmergencyOfficialRole());
        roles.add(new MaintenanceRole());
        roles.add(new TenantRole());
        roles.add(new LawyerRole());
        roles.add(new LeasingAgentRole());
       //  roles.add(new PoliceHead());
        return roles;
    }
    
}
