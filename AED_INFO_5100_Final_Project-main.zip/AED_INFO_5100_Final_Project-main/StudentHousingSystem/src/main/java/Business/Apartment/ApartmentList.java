/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Apartment;

import java.util.ArrayList;

/**
 *
 * @author sharvikabarapatre
 */
public class ApartmentList {
    private ArrayList<Apartment> apartmentList;

    public ApartmentList() {
        this.apartmentList = new ArrayList();
    }
    
    public Apartment addNewEquip(String apartmentName, String Desc, String availableQuant, double cost,double totalcost)
        
        
    {
        Apartment apartment = new Apartment(apartmentName, Desc, availableQuant, cost,totalcost);
        apartmentList.add(apartment);
        return apartment;
        
    }  

    public ArrayList<Apartment> getApartmentList() {
        return apartmentList;
    }

    public void setApartmentList(ArrayList<Apartment> apartmentList) {
        this.apartmentList = apartmentList;
    }
    
    
}
