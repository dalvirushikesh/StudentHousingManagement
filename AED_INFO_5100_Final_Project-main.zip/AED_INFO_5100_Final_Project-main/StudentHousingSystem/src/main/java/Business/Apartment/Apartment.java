/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Apartment;

/**
 *
 * @author sharvikabarapatre
 */
public class Apartment {
    
    private String apartmentID;
    private String apartmentName;
    private String availableQuant;
    private String desc;
    private double cost;
    private double TotalCost;
     int min = 100;
    int max = 999;

    public Apartment(String apartmentName, String desc, String availableQuant, double cost, double totalcost) {
        this.apartmentID = apartmentID;
        this.apartmentName = apartmentName;
        this.availableQuant = availableQuant;
        this.cost = cost;
        this.desc = desc;
        this.TotalCost = totalcost;
          int randomNum = (int)(Math.random() * (max - min + 1) + min);
        apartmentID= "EQ-"+randomNum;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

      
    
    
    public String getApartmentID() {
        return apartmentID;
    }

    public void setApartmentID(String apartmentID) {
        this.apartmentID = apartmentID;
    }

    public String getApartmentName() {
        return apartmentName;
    }

    public void setApartmentName(String apartmentName) {
        this.apartmentName = apartmentName;
    }

    public String getAvailableQuant() {
        return availableQuant;
    }

    public void setAvailableQuant(String availableQuant) {
        this.availableQuant = availableQuant;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
    
    @Override
    public String toString()
    {
        return this.apartmentName;
    }
    
    
}
