/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.ApartmentDetails;

import java.util.ArrayList;

/**
 *
 * @author S
 */
public class ApartmentDetailsList {
    private ArrayList<ApartmentDetails> history;
    
    public ApartmentDetailsList()
    {
        history = new ArrayList();
    }

    public ArrayList<ApartmentDetails> getHistory() {
        return history;
    }

    public void setHistory(ArrayList<ApartmentDetails> history) {
        this.history = history;
    }
    
    
}
