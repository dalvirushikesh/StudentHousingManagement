/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.ApartmentDetails;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author S
 */
public class ApartmentDetails {
    
     private int noOfRoom;
    private int noOfBath;
    private int area;
    private int floor;
    private Date date;
    
    public int getNoOfRoom() {
        return noOfRoom;
    }

    public void setNoOfRoom(int noOfRoom) {
        this.noOfRoom = noOfRoom;
    }

    public int getNoOfBath() {
        return noOfBath;
    }

    public void setNoOfBath(int noOfBath) {
        this.noOfBath = noOfBath;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public Date getDate() {
        SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm:ss a");
        return date;
    }

    public void setDate(Date date) {
        SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm:ss a");
        this.date = date;
    }

    @Override
    public String toString() {
        SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm:ss a");
        return ft.format(date);
    }
}
