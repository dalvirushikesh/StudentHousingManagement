
# PROBLEM STATEMENT

- Every Spring or Fall Semester students face challenge of searching apartments 
- Students moving to different cities for education face problems while house hunting . As students are new to the place they are unaware of the areas and facilities available . 
- Student Housing service has been considered as rare and not many establishments are there to help . 
- Already existing housing systems lack facility of maintenance and security assistance which is very important these days . 
- The renting and billing process is very time consuming and cumbersome for students , so they avoid getting into it .
- Current Housing System lack multiple departments integrated in one system . 


# Solution

- Student Housing System is a service provider for students who have moved to new city and in search of apartment .

- Student Housing System has apartments which have facility where tenant can raise  maintenance or security assistance request which is properly routed from all the necessary enterprise and organizations quickly so that the tenant in distress can be helped . 

- Provides the facility of lawyer assistance for legal documentation .

- In our system , we have integrated all the necessary roles like billing , renting , lawyer assistance , landlord , maintenance and security  so tenant and landlord will have common platform  to access the service . 

# USe Case
![image](https://user-images.githubusercontent.com/99000699/166180397-c8a06899-4ff7-4b13-a8bf-6fb1865839da.png)


